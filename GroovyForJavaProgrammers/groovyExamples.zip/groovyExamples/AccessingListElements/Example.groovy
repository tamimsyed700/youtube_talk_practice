lst = [1, 'hello', 'a', 3.2]

println "Size of lst is ${lst.size()}"
println "Element 0 is ${lst.get(0)}"
println "Element 2 is ${lst[2]}"

lst[3] = 'test'
println lst

lst[2] = ['how', 'about', 'this', 1]
println lst

lst.putAt(1, 'replaced')
println lst

lst.putAt(1..0, 'inserted')
println lst

lst.putAt(2..1, ['some', 'more'])
println lst

print 'Result of flatten:'
println lst.flatten()

