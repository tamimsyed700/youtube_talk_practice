def check(str, closure)
{
	if (str =~ '(G|g)roovy')
		closure.call(str, true);
	else
		closure.call(str, false);
}

dispClosure = { str, res | 
	println "Match found for ${str}?: ${res}" }

check('Groovy', dispClosure)
check('groovy', dispClosure)
check('Gooovy', dispClosure)

println "Result of 'Groovy'.split('o+')"
'Groovy'.split('o+').each { println it }

