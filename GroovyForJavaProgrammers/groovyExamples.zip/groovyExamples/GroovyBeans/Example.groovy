class Car
{
	int year
	private int miles = 0
	public int getMiles() { miles }

	public drive() { miles++ }
}

aCar = new Car(year : 2005, miles : 100)

println aCar.getYear()
println aCar.getMiles()
for(i in 1..100) { aCar.drive() }

println aCar.Miles

// year is a read-write property in this example
aCar.setYear(2006) 

println aCar.Year
aCar.Year = 2007
aCar.Miles = 7

