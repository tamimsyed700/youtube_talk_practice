map = ['C++' : 'Stroustrup', 'Java' : 'Gosling', 'C#' : 'Hejlsberg']

println "map['Java'] = ${map['Java']}"

println "map.Java = ${map.Java}"
println "map has ${map.size()} elements"

println "map contains:"
map.each {key, value | println "${key} = ${value}"}

