new java.io.File('quote.txt').eachLine {
	println it
}

