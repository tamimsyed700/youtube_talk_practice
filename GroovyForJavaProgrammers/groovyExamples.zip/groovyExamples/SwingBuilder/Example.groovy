// Closure
setLabel = { lbl | lbl.setText(new Date().toString()) }

swingBldr = new groovy.swing.SwingBuilder()


frame = swingBldr.frame(
	title : "Example", 
	size:[200, 100],
	layout: new java.awt.FlowLayout(),
	defaultCloseOperation:javax.swing.WindowConstants.EXIT_ON_CLOSE) {

	myLabel = label(text: "Hello")
	button(text : 'Click', actionPerformed: {  setLabel(myLabel) })
}

frame.show()

