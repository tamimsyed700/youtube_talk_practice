import groovy.xml.MarkupBuilder

map = ['C++' : 'Stroustrup', 'Java' : 'Gosling', 'C#' : 'Hejlsberg']

markupBldr = new MarkupBuilder()

xml = markupBldr.languages {
	for(entry in map)
	{
		language(name : entry.key) {
			author (entry.value)
		}	
	}
}
