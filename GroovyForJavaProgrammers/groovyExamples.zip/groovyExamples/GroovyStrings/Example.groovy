map = ['C++' : 'Stroustrup', 'Java' : 'Gosling', 'C#' : 'Hejlsberg']

println '<languages>'
map.each { key, value | 
println "	<language>
		<name>${key}</name>
		<author>${value}</author>
	</language>"
}
println '</languages>'

