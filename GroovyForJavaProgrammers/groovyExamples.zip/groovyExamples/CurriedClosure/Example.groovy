class Car {
	int year
	int miles
}

def dispInfo(aCar, closure)
{
	closure("Car", "Year:", aCar.getYear())
	closure("Car", "Miles:", aCar.getMiles())
}


def dispInfo2(aCar, closure)
{
	curried = closure.curry("Car")
	curried("Year:", aCar.getYear())
	curried("Miles:", aCar.getMiles())
}

myCar = Car.newInstance()
myCar.setYear(2005)
myCar.setMiles(100)

dispInfo(myCar) { header, msg, value | 
	println "${header}: ${msg}\t=\t${value}" }
println "Curried  call:"
dispInfo2(myCar) { header, msg, value | 
	println "${header}: ${msg}\t=\t${value}" }

