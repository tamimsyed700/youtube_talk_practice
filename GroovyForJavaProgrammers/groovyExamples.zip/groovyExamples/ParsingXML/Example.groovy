languages = new XmlParser().parse("input.xml")

println "Lang\tAuthor"
println "=================="

languages.each { 
	print it['@name']
	print '\t'
	println it.author[0].text() }

