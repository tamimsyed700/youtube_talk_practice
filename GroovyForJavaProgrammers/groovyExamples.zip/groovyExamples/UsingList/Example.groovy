lst = [1, 2]
total = 0

for(val in lst)
{
	total += val
}

println total