import java.util.*;

public class Example
{
	public static void main(String[] args)
	{
		List<Integer> lst = new ArrayList<Integer>();
		lst.add(1);
		lst.add(2);

		int total = 0;

		for(int val : lst)
		{
			total += val;
		}

		System.out.println(total);
	}
}