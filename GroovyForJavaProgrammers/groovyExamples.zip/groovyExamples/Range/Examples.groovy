str = "Hello"

println str[0]
println str[1..4]
println str[2..0]
println str[2..-1]


