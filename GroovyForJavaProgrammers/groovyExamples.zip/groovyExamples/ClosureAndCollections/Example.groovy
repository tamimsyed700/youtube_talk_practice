lst = [1, 2, 3, 8]

print "Elements in lst are:"

lst.each { print "${it} " }

println ""
print "List with each element incremented:"
println lst.collect { it + 1 }

found = lst.find { println "find sent ${it}"; it == 3 }
println "found ${found}"

println "lst with elements > 2: ${lst.findAll { it > 2 }}"
println "Total of elements: " + 
	lst.inject(0) { carryOver, item | carryOver + item }
println "Elements joined with ~ : " + lst.join('~')

