str = "Hello"

print "Encrypting ${str}:"
use(PoorMansEncryption.class) {
	str.encrypt() { print it }
}

println ""

class PoorMansEncryption
{
	public static void encrypt(self, closure)
	{
		self.each { closure(it.next())}
	}
}

