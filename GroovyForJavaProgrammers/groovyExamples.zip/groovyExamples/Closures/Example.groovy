def createEven(upTo, closure)
{
	for(i in 2..upTo)
	{
		if (i % 2 == 0) closure.call(i)	
	}
}

createEven(10) { println it }

print "Total of even numbers from 2 to 10 is:"

total = 0

createEven(10) { anEven | total += anEven }
println total

