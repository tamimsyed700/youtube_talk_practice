c = 'A'
print "Char next to ${c} is:"
c++
println c 

str = 'working hard'
println str + '?'
str += 'ly!'
str -= 'working '
println str

myVector = new VenkatsVector()
println myVector

anotherVector = myVector + myVector
println anotherVector

class VenkatsVector
{
	vals = [1, 2, 3]

	VenkatsVector plus(VenkatsVector v)
	{
		for(i in 1..vals.size())
		{
			vals[i-1] += v.vals[i-1]
		}

		this
	}

	public String toString()
	{
		vals
	}
}

