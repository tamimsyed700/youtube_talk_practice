x = 1
println x

x = new Date()
println x

x = "test"
println x
