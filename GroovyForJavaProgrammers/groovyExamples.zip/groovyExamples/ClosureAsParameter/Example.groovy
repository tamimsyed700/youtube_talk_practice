def createEven(closure, upTo)
{
	for(i in 2..upTo)
	{
		if (i % 2 == 0) closure.call(i)	
	}
}

createEven({ println it }, 10)

print "Total of even numbers from 2 to 10 is:"

total = 0

createEven({ anEven | total += anEven }, 10)
println total

