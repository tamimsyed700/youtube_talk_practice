// I've added Temperatures.xls as 
//a ODBC datasource named 'Temperatures'

import groovy.sql.Sql

sql = Sql.newInstance(
	'jdbc:odbc:Temperatures', '', '', 
	'sun.jdbc.odbc.JdbcOdbcDriver')

println 'City\tTemperature'
println '==================='

sql.eachRow('select * from [TemperatureValues$]') { 
		println "${it.City}\t${it.temperature}" }

