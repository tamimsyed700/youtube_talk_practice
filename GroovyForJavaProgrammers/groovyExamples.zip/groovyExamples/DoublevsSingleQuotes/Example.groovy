println 'hello'
println "hello"
println 'time is ${new Date()}'
println "time is ${new Date()}"